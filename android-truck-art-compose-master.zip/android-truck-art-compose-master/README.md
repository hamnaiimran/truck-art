# Jetpack Compose Truck Art  
  In this project I have explored Canvas in Jetapck Compose. Using basic shapes of Canvas API I designed an interesting truck art.

![alt text](https://github.com/JunydDEV/android-truck-art-compose/blob/master/images/truck-art-banner.png)

# Shapes 
<p> ✅ Rectangle </p>
<p> ✅ Circle </p>
<p> ✅ Line </p>
<p> ✅ Path </p>

# Coordinates Systems
<p> ✅ Cartisian Coordinates System</p>
<p> ✅ Polar Coordinates System </p>

# TODO
<p> ✅ Custom shapes</p>
<p> ✅ Animations</p>

